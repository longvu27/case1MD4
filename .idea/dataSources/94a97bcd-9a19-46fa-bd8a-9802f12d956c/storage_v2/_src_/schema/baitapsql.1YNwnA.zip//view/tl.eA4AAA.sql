create definer = root@localhost view tl as
select `o`.`id` AS `id`, `o`.`time` AS `time`
from ((`baitapsql`.`orderdetail` `od` join `baitapsql`.`product` `p`) join `baitapsql`.`order` `o`)
where ((`od`.`productId` = `p`.`id`) and (`o`.`id` = `od`.`orderId`) and (`p`.`name` like 'Tủ Lạnh'));


create definer = root@localhost view top3p as
select `baitapsql`.`product`.`price` AS `price`
from `baitapsql`.`product`
group by `baitapsql`.`product`.`price`
order by `baitapsql`.`product`.`price` desc
limit 3;

